"""
master_data_engine.py
=====================
Aggregates daily data from Grid_Diesel and Unified_Solar into the Master-data Excel file.
Designed to run once daily (e.g., at 08:00 AM) to process the previous day's data.
Usage:
  python master_data_engine.py               # Processes yesterday's data
  python master_data_engine.py 2026-04-08    # Processes a specific date
"""
import math
import os
import sys
import io
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
import requests
import pandas as pd
from dotenv import load_dotenv

# ──────────────────────────────────────────────────────────────────────────────
# Logging Setup
# ──────────────────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Configuration & Environment
# ──────────────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent

def _load_env() -> None:
    search_paths = [SCRIPT_DIR, SCRIPT_DIR.parents[0], SCRIPT_DIR.parents[1], Path.cwd()]
    for path in search_paths:
        env_file = path / ".env"
        if env_file.exists():
            load_dotenv(dotenv_path=env_file)
            return
    load_dotenv()
_load_env()

TENANT_ID = os.getenv("SHAREPOINT_TENANT_ID", "").strip()
CLIENT_ID = os.getenv("SHAREPOINT_CLIENT_ID", "").strip()
CLIENT_SECRET = os.getenv("SHAREPOINT_CLIENT_SECRET", "").strip()
GRID_RATE = float(os.getenv("GRID_RATE_INR_PER_KWH", "7.11"))

HOSTNAME    = os.getenv("SHAREPOINT_HOSTNAME", "").strip()
SITE_PATH   = os.getenv("SHAREPOINT_SITE_PATH", "/Admin").strip()
DRIVE_NAME  = os.getenv("SHAREPOINT_DRIVE_NAME", "").strip()
BASE_FOLDER = os.getenv("SHAREPOINT_BASE_FOLDER", "").strip()
GRAPH_BASE  = "https://graph.microsoft.com/v1.0"

if not all([HOSTNAME, DRIVE_NAME, BASE_FOLDER]):
    raise RuntimeError(
        "master_data_engine: SHAREPOINT_HOSTNAME, SHAREPOINT_DRIVE_NAME, "
        "and SHAREPOINT_BASE_FOLDER must be set in environment."
    )

_access_token: Optional[str] = None
_site_id: Optional[str] = None
_drive_id: Optional[str] = None

# ──────────────────────────────────────────────────────────────────────────────
# SharePoint Graph API Helpers
# ──────────────────────────────────────────────────────────────────────────────
import time
_access_token: Optional[str] = None
_token_expiry: float = 0.0

def _get_token() -> str:
    global _access_token, _token_expiry
    if _access_token and time.time() < _token_expiry - 60:
        return _access_token
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    resp = requests.post(url, data={
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "scope": "https://graph.microsoft.com/.default",
    }, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    _access_token = data["access_token"]
    _token_expiry = time.time() + data.get("expires_in", 3600)
    return _access_token

def _get_site_and_drive_ids() -> tuple[str, str]:
    global _site_id, _drive_id
    if _site_id and _drive_id:
        return _site_id, _drive_id
    headers = {"Authorization": f"Bearer {_get_token()}"}

    site_resp = requests.get(f"{GRAPH_BASE}/sites/{HOSTNAME}:{SITE_PATH}", headers=headers, timeout=30)
    site_resp.raise_for_status()
    _site_id = site_resp.json()["id"]

    drives_resp = requests.get(f"{GRAPH_BASE}/sites/{_site_id}/drives", headers=headers, timeout=30)
    drives_resp.raise_for_status()
    for drive in drives_resp.json().get("value", []):
        if drive["name"] == DRIVE_NAME:
            _drive_id = drive["id"]
            break
    if not _drive_id:
        raise RuntimeError(f"Drive '{DRIVE_NAME}' not found in site '{_site_id}'")
    return _site_id, _drive_id

def upload_excel(filename: str, df: pd.DataFrame) -> None:
    site_id, drive_id = _get_site_and_drive_ids()
    file_path = f"{BASE_FOLDER}{filename}"
    safe_path = requests.utils.quote(file_path, safe="/")
    url = f"{GRAPH_BASE}/sites/{site_id}/drives/{drive_id}/root:/{safe_path}:/content"
    
    output_buffer = io.BytesIO()
    with pd.ExcelWriter(output_buffer, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Sheet1', index=False)
    output_buffer.seek(0)
    
    headers = {
        "Authorization": f"Bearer {_get_token()}",
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    }
    resp = requests.put(url, headers=headers, data=output_buffer.read())
    resp.raise_for_status()

def download_excel(filename: str) -> pd.DataFrame:
    import io
    site_id, drive_id = _get_site_and_drive_ids()
    file_path = f"{BASE_FOLDER}{filename}"
    safe_path = requests.utils.quote(file_path, safe="/")
    url = f"{GRAPH_BASE}/sites/{site_id}/drives/{drive_id}/root:/{safe_path}:/content"
    
    resp = requests.get(url, headers={"Authorization": f"Bearer {_get_token()}"})
    resp.raise_for_status()
    df = pd.read_excel(io.BytesIO(resp.content), sheet_name="Sheet1")
    
    if any("Unnamed" in str(c) for c in df.columns):
        logger.info(f"Detected 'Unnamed' columns in {filename}. Hunting for real headers...")
        for i, row in df.head(10).iterrows():
            if any("date" in str(val).lower() for val in row.values):
                df.columns = [str(c).strip().replace('\n', ' ') for c in row.values]
                df = df.iloc[i+1:].reset_index(drop=True)
                logger.info(f"✅ Found real headers and fixed the table for {filename}!")
                break
    else:
        df.columns = [str(c).strip().replace('\n', ' ') for c in df.columns]
    return df

# ──────────────────────────────────────────────────────────────────────────────
# Core Logic
# ──────────────────────────────────────────────────────────────────────────────
def _safe_float(val) -> float:
    try: return float(str(val).replace(',', '').strip())
    except (TypeError, ValueError, AttributeError): return 0.0

def _robust_parse_date(series: pd.Series) -> pd.Series:
    parsed = pd.to_datetime(series, errors="coerce")
    if parsed.isna().any():
        fallback_str = series.astype(str).str.strip()
        parsed = parsed.fillna(pd.to_datetime(fallback_str, format="%d-%b-%y", errors="coerce"))
        parsed = parsed.fillna(pd.to_datetime(fallback_str, errors="coerce", dayfirst=True))
    return parsed.dt.strftime("%Y-%m-%d")

def _get_fuzzy(row: pd.Series, keyword: str, default: any = ""):
    kw_lower = keyword.lower().replace(" ", "").replace("\n", "")
    for col in row.index:
        col_lower = str(col).lower().replace(" ", "").replace("\n", "")
        if kw_lower in col_lower:
            val = row[col]
            if pd.isna(val) or str(val).strip() == "":
                return default
            if kw_lower == "time":
                try:
                    return pd.to_datetime(val).strftime("%H:%M")
                except:
                    return str(val).strip()[:5]
            return val
    return default

def _normalize_key(value: str) -> str:
    return str(value).lower().replace(" ", "").replace("_", "").replace("\n", "")

def _get_from_candidates(row: pd.Series, candidates: list[str], default: any = ""):
    lookup: dict[str, str] = {}
    for col in row.index:
        key = _normalize_key(col)
        lookup.setdefault(key, str(col))
    for candidate in candidates:
        source_col = lookup.get(_normalize_key(candidate))
        if not source_col:
            continue
        val = row[source_col]
        if pd.isna(val) or str(val).strip() == "":
            continue
        return val
    return default
 
def _get_peak_automated_solar_units(solar_rows: pd.DataFrame) -> float:
    if solar_rows is None or solar_rows.empty:
        return 0.0
    candidate_rows = solar_rows
    if "Time" in solar_rows.columns:
        parsed_times = pd.to_datetime(solar_rows["Time"], errors="coerce").dt.strftime("%H:%M")
        upto_1930 = solar_rows[parsed_times.notna() & (parsed_times <= "19:30")]
        if not upto_1930.empty:
            candidate_rows = upto_1930
    solar_candidates = candidate_rows.apply(
        lambda row: _safe_float(_get_fuzzy(row, "daygeneration", _get_fuzzy(row, "solar", 0))),
        axis=1,
    )
    if solar_candidates.empty:
        return 0.0
    return float(solar_candidates.max())

def _compute_solar_units_from_unified(df_solar: pd.DataFrame, for_date: str) -> Optional[float]:
    if df_solar is None or df_solar.empty:
        return None
    work = df_solar.copy()
    if "Date" not in work.columns:
        return None
        
    work["_date"] = pd.to_datetime(work["Date"], errors="coerce").dt.date
    time_col = next((c for c in work.columns if _normalize_key(c) == "time"), None)
    if time_col:
        work["_time"] = pd.to_datetime(work[time_col], format="mixed", errors="coerce")

    else:
        work["_time"] = pd.NaT
        
    target_date = pd.to_datetime(for_date, errors="coerce")
    if pd.isna(target_date):
        return None
        
    today = target_date.date()
    yesterday = (target_date - timedelta(days=1)).date()
    
    def _norm(value: str) -> str:
        return "".join(ch for ch in str(value).lower() if ch.isalnum())
        
    ygen_col = next((c for c in work.columns if _norm(c) in {"yesterdaygen", "yesterdaygenerationkwh", "yesterdaygeneration"}), None)
    daygen_col = next((c for c in work.columns if _norm(c) in {"daygenerationkwh", "daygeneration"}), None)
    
    today_ygen = 0.0
    if ygen_col:
        today_rows = work[work["_date"] == today].copy()
        if not today_rows.empty:
            today_rows = today_rows.sort_values("_time")
            today_ygen = _safe_float(today_rows.iloc[-1].get(ygen_col, 0))
            
    yday_last_daygen = 0.0
    if daygen_col:
        yday_rows = work[work["_date"] == yesterday].copy()
        if not yday_rows.empty:
            yday_rows = yday_rows.sort_values("_time")
            yday_last_daygen = _safe_float(yday_rows.iloc[-1].get(daygen_col, 0))
            
    selected = max(today_ygen, yday_last_daygen)
    logger.info(
        "Solar Units compare from UnifiedSolarData for %s: today[YGen]=%s, yesterday[last DayGen]=%s, selected=%s",
        for_date,
        today_ygen,
        yday_last_daygen,
        selected,
    )
    return float(selected)

# ──────────────────────────────────────────────────────────────────────────────
# Inverter Uptime Loader (with full fallback chain)
# ──────────────────────────────────────────────────────────────────────────────
def _load_inverter_uptime(date_str: str) -> dict:
    """
    Load per-inverter uptime/downtime for a given date from inverter_tracker.json.

    Fallback chain:
      1. Try importing get_inverter_uptime_for_date from inverter_monitor (preferred —
         uses the same path resolution logic as the monitor itself).
      2. If that import fails, locate and read inverter_tracker.json directly using
         the same path logic the monitor uses (Azure vs local).
      3. If the file is missing or unreadable, return {} so all 10 uptime/downtime
         columns are written as 0.0 and the rest of the master row is unaffected.

    Returns:
        {
          "Inverter1": {"uptime_hrs": 6.5, "downtime_hrs": 0.5},
          ...
        }
        or {} if no data found for date_str.
    """
    INVERTERS = ["Inverter1", "Inverter2", "Inverter3", "Inverter4", "Inverter5"]

    # ── Attempt 1: delegate to inverter_monitor ───────────────────────────────
    try:
        from app.services.inverter_monitor import get_inverter_uptime_for_date
        result = get_inverter_uptime_for_date(date_str)
        if result is not None:
            return result
        # result is None → no data for this date; fall through to log + return {}
        logger.warning(
            f"[INVERTER] inverter_monitor returned None for {date_str}. "
            "Uptime columns will be 0.0."
        )
        return {}
    except ImportError:
        logger.warning(
            "[INVERTER] Could not import inverter_monitor. "
            "Falling back to direct tracker file read."
        )
    except Exception as e:
        logger.error(
            f"[INVERTER] get_inverter_uptime_for_date raised an unexpected error: {e}. "
            "Falling back to direct tracker file read."
        )

    # ── Attempt 2: read tracker JSON directly ─────────────────────────────────
    import json as _json
    try:
        if "WEBSITE_SITE_NAME" in os.environ:
            tracker_path = Path("/home/LogFiles/energy-dashboard/output/inverter_tracker.json")
        else:
            base = Path(__file__).resolve().parent.parent.parent
            tracker_path = base / "energy-dashboard" / "output" / "inverter_tracker.json"

        if not tracker_path.exists():
            logger.warning(
                f"[INVERTER] Tracker file not found at {tracker_path}. "
                "Uptime columns will be 0.0."
            )
            return {}

        with open(tracker_path, "r", encoding="utf-8") as f:
            tracker = _json.load(f)

        day_data = tracker.get(date_str)
        if not day_data:
            logger.warning(
                f"[INVERTER] No tracker entry for {date_str} in {tracker_path}. "
                "Uptime columns will be 0.0."
            )
            return {}

        result = {}
        for inv in INVERTERS:
            entry = day_data.get(inv, {"uptime_mins": 0, "downtime_mins": 0})
            result[inv] = {
                "uptime_hrs":   round(entry.get("uptime_mins", 0) / 60, 2),
                "downtime_hrs": round(entry.get("downtime_mins", 0) / 60, 2),
            }
        logger.info(f"[INVERTER] Loaded uptime from tracker file for {date_str}: {result}")
        return result

    except (OSError, _json.JSONDecodeError, Exception) as e:
        logger.error(
            f"[INVERTER] Failed to read tracker file directly: {e}. "
            "Uptime columns will be 0.0."
        )
        return {}


def process_master_data(
    operator_date: str,
    solar_date: str,
    fallback_operator_date: Optional[str] = None,
) -> None:
    logger.info(f"=== Master Data Engine: operator_date={operator_date}, solar_date={solar_date} ===")
    
    # 1. Download BOTH source files
    logger.info("Downloading Electrical Optimization (1).xlsx (Operator Data)...")
    df_grid = download_excel("Electrical Optimization (1).xlsx")
    logger.info("Downloading UnifiedSolarData.xlsx (Automated Solar Data)...")
    df_solar = download_excel("UnifiedSolarData.xlsx")
    
    # 2. Parse dates safely
    df_grid['Date'] = _robust_parse_date(df_grid['Date'])
    df_solar['Date'] = _robust_parse_date(df_solar['Date'])
    
    # 3. Filter for the exact requested target dates (Avoids Monday duplicate issues)
    grid_rows  = df_grid[df_grid['Date'] == operator_date]   # operator wrote today's date
    solar_rows = df_solar[df_solar['Date'] == solar_date]    # scraper ran on yesterday
    
    grid_source_date = operator_date
    if grid_rows.empty and fallback_operator_date:
        fallback_rows = df_grid[df_grid['Date'] == fallback_operator_date]
        if not fallback_rows.empty:
            grid_rows = fallback_rows
            grid_source_date = fallback_operator_date
            logger.warning(
                "No operator row found for %s. Using fallback operator row from %s.",
                operator_date,
                fallback_operator_date,
            )
            
    if grid_rows.empty:
        logger.error(f"❌ No Operator Grid/Diesel data found for {operator_date}. Aborting.")
        return
        
    grid_today = grid_rows.iloc[-1]
    
    # 4. Extract Grid Data purely from Operator Sheet
    grid_units = _safe_float(_get_fuzzy(grid_today, "gridunits", 0))
    grid_cost_inr = _safe_float(_get_fuzzy(grid_today, "consumedin", 0))
    
    # 5. Extract Solar Data from UnifiedSolarData using requested max logic.
    automated_solar_units = 0.0
    calculated_solar_units = _compute_solar_units_from_unified(df_solar, operator_date)
    if calculated_solar_units is not None:
        automated_solar_units = calculated_solar_units
        
    if automated_solar_units > 0:
        solar_units = automated_solar_units
        solar_source = "UnifiedSolarData Max Rule"
    else:
        logger.warning(
            "UnifiedSolarData max-rule value is missing/zero for %s. Falling back to day peak for %s.",
            operator_date,
            solar_date,
        )
        fallback_peak = _get_peak_automated_solar_units(solar_rows) if not solar_rows.empty else 0.0
        solar_units = fallback_peak
        solar_source = "Automated Day-Peak Fallback"
        
    # 6. Calculate True Totals
    total_units = grid_units + solar_units
    energy_savings_inr = solar_units * GRID_RATE
    
    logger.info(f"   Grid Units: {grid_units} kWh")
    if grid_source_date != operator_date:
        logger.info(f"   Grid source row date (fallback): {grid_source_date}")
    logger.info(f"   Solar Units: {solar_units} kWh (Source: {solar_source})")
    logger.info(f"   Calculated Total Units: {total_units} kWh")
    logger.info(f"   Grid Cost (INR): ₹{grid_cost_inr:,.2f}")
    logger.info(f"   Calculated Savings (INR): ₹{energy_savings_inr:,.2f}")
    
    # 🚀 THE FIX: Determine the Day strictly using the Operator Date
    consumption_dt = pd.to_datetime(solar_date, errors="coerce")

    if pd.isna(consumption_dt):
        logger.error(f" Invalid solar_date: {solar_date!r}. Aborting.")
        return
    
    # 7. Build the Master Row
    master_row = {
        "Date": solar_date,                      
        "Day":  consumption_dt.strftime("%A"), # This now correctly outputs "Monday" on Mondays!
        "Time": _get_fuzzy(grid_today, "time", "09:00"),
        "Ambient Temperature °C": _get_fuzzy(grid_today, "ambient", ""),
        "Grid Units Consumed (KWh)": grid_units,
        "Solar Units Consumed(KWh)": solar_units,
        "Total Units Consumed (KWh)": total_units,
        "Total Units Consumed in INR": math.ceil(grid_cost_inr),
        "Energy Saving in INR": math.ceil(energy_savings_inr),
        "Number of Panels Cleaned": _get_fuzzy(grid_today, "panelscleaned", 0),
        "Diesel consumed": _get_fuzzy(grid_today, "diesel", "0"),
        "Water treated through STP": _get_fuzzy(grid_today, "stp", "0"),
        "Water treated through WTP": _get_fuzzy(grid_today, "wtp", "0"),
        "Issues": _get_fuzzy(grid_today, "issues", "No issues"),
        "Inverter_1": _get_fuzzy(grid_today, "inv_1", ""),
        "Inverter_2": _get_fuzzy(grid_today, "inv_2", ""),
        "Inverter_3": _get_fuzzy(grid_today, "inv_3", ""),
        "Inverter_4": _get_fuzzy(grid_today, "inv_4", ""),
        "Inverter_5": _get_fuzzy(grid_today, "inv_5", ""),
    }

    # ── Inverter Uptime / Downtime ────────────────────────────────────────────
    # solar_date is the actual day the inverters were running (yesterday relative
    # to when operator submits). inverter_monitor.py writes tracker keyed by the
    # calendar date the data belongs to, which matches solar_date here.
    inverter_uptime = _load_inverter_uptime(solar_date)
    for inv in ["Inverter1", "Inverter2", "Inverter3", "Inverter4", "Inverter5"]:
        inv_data = inverter_uptime.get(inv, {"uptime_hrs": 0.0, "downtime_hrs": 0.0})
        master_row[f"{inv}_Uptime (hrs)"]   = inv_data["uptime_hrs"]
        master_row[f"{inv}_Downtime (hrs)"] = inv_data["downtime_hrs"]

    if not inverter_uptime:
        logger.warning(
            f"No inverter tracker data for {solar_date}. "
            "Uptime/downtime columns written as 0.0."
        )
    
    # 8. Push to Master Data
    logger.info("Downloading Master-data.xlsx...")
    df_master = download_excel("Master-data.xlsx")
    df_master['Date_Str'] = _robust_parse_date(df_master['Date'])
    
    # 🚀 The deduplication check cleanly matches the exact date inserted.
    df_master = df_master[df_master['Date_Str'] != solar_date].drop(columns=['Date_Str'])
    
    new_df = pd.DataFrame([master_row])
    df_master = pd.concat([df_master, new_df], ignore_index=True)
    
    logger.info("Uploading updated Master-data.xlsx to SharePoint...")
    upload_excel("Master-data.xlsx", df_master)
    logger.info(" Master data synchronization SUCCESS!")

if __name__ == "__main__":
    import sys
    from datetime import datetime, timedelta
    from zoneinfo import ZoneInfo

    IST = ZoneInfo("Asia/Kolkata")
    now = datetime.now(IST)

    # argv[1] = operator_date (TODAY)      e.g. 2026-04-13
    # argv[2] = solar_date    (YESTERDAY)  e.g. 2026-04-12
    # argv[3] = fallback_operator_date      e.g. 2026-04-13
    operator_date          = sys.argv[1] if len(sys.argv) > 1 else now.strftime("%Y-%m-%d")
    solar_date             = sys.argv[2] if len(sys.argv) > 2 else (now - timedelta(days=1)).strftime("%Y-%m-%d")
    fallback_operator_date = sys.argv[3] if len(sys.argv) > 3 else None

    # ── Gate: only run when Grid & Diesel data actually exists ────────────────
    # The scheduler already calls check_grid_diesel_entry_exists() before
    # spawning this subprocess, but we re-check here as a hard safety net so
    # the engine never writes a row of zeros if invoked manually or retried
    # from a stale context where the gate was skipped.
    #
    # Re-check is done by downloading the operator sheet directly (same file the
    # scheduler inspects) rather than importing scheduler_service, which would
    # pull in APScheduler and all its dependencies unnecessarily.
    logger.info(
        "=== Master Data Engine gate check: verifying Grid & Diesel data "
        f"exists for operator_date={operator_date} before proceeding ==="
    )

    try:
        df_gate = download_excel("Electrical Optimization (1).xlsx")
        df_gate["_parsed_date"] = _robust_parse_date(df_gate["Date"])

        gate_rows = df_gate[df_gate["_parsed_date"] == operator_date]
        if gate_rows.empty and fallback_operator_date:
            gate_rows = df_gate[df_gate["_parsed_date"] == fallback_operator_date]

        if gate_rows.empty:
            logger.error(
                f"❌ Gate FAILED: No Grid & Diesel row found for operator_date={operator_date}"
                + (f" or fallback={fallback_operator_date}" if fallback_operator_date else "")
                + ". Engine will NOT run — no data to write."
            )
            sys.exit(0)   # exit 0 so the scheduler doesn't log this as a subprocess crash

        # Check that the row has a non-blank Grid Units value
        def _norm(name: str) -> str:
            return str(name).lower().replace(" ", "").replace("_", "").replace("\n", "")

        grid_units_col = next(
            (c for c in gate_rows.columns if "grid" in _norm(c) and "unit" in _norm(c)),
            None,
        )
        if grid_units_col is None:
            logger.warning(
                "[GATE] Could not locate Grid Units column — proceeding anyway "
                "(column check is best-effort)."
            )
        else:
            latest_gate_row = gate_rows.iloc[-1]
            raw_val = latest_gate_row.get(grid_units_col, None)
            if raw_val is None or str(raw_val).strip().lower() in ("", "nan", "none", "null"):
                logger.error(
                    f"❌ Gate FAILED: Grid Units column is blank for {operator_date}. "
                    "Engine will NOT run."
                )
                sys.exit(0)

        logger.info(
            f"✅ Gate PASSED: Grid & Diesel data confirmed for {operator_date}. "
            "Proceeding with master data engine."
        )

    except Exception as gate_err:
        logger.error(
            f"❌ Gate check itself failed ({gate_err}). "
            "Aborting engine as a safety measure — cannot confirm data exists."
        )
        sys.exit(1)

    # ── Run the engine ────────────────────────────────────────────────────────
    try:
        process_master_data(operator_date, solar_date, fallback_operator_date)
    except Exception as e:
        logger.error(f"❌ Master Engine Failed: {e}")
        sys.exit(1)