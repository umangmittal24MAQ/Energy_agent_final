# Core application module
